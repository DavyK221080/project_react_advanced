import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import EventsPage from "./pages/EventsPage";
import AddEvent from "./pages/AddEvent";
import EventPage from "./pages/EventPage";
import Navigation from "./components/Navigation";

function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/events" element={<EventsPage />} />
        <Route path="/add-event" element={<AddEvent />} />
        <Route path="/events/:id" element={<EventPage />} />
      </Routes>
    </Router>
  );
}

export default App;
