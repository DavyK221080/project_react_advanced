import React from "react";
import { Outlet, Link } from "react-router-dom";
import { Box, Flex, Heading } from "@chakra-ui/react";

const Root = () => {
  return (
    <Box>
      <Flex as="nav" p="4" bg="teal.500" color="white" mb="8">
        <Heading size="lg">
          <Link to="/">Event Dashboard</Link>
        </Heading>
        <Box ml="auto">
          <Link to="/" style={{ marginRight: 15 }}>
            Events
          </Link>
          <Link to="/add-event">Add Event</Link>
        </Box>
      </Flex>
      <Outlet />
    </Box>
  );
};

export default Root;
