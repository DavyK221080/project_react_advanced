import React from "react";
import { Link } from "react-router-dom";
import { Box, Button } from "@chakra-ui/react";

const Navigation = () => (
  <Box p={4} bg="gray.100" mb={4}>
    <Button as={Link} to="/" mr={4} color="darkblue">
      Home
    </Button>
    <Button as={Link} to="/about" mr={4} color="darkblue">
      About
    </Button>
    <Button as={Link} to="/events" mr={4} color="darkblue">
      Events
    </Button>
    <Button as={Link} to="/add-event" mr={4} color="darkblue">
      Add Event
    </Button>
  </Box>
);

export default Navigation;
