import React, { useState, useEffect } from "react";
import {
  Box,
  Input,
  Button,
  Textarea,
  Select,
  useToast,
  Flex,
  Text,
} from "@chakra-ui/react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EditEvent = () => {
  const { id } = useParams();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [location, setLocation] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [categoryIds, setCategoryIds] = useState([]);
  const [categories, setCategories] = useState([]);
  const toast = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEvent = async () => {
      const eventResponse = await axios.get(
        `http://localhost:3000/events/${id}`
      );
      const event = eventResponse.data;
      setTitle(event.title);
      setDescription(event.description);
      setImage(event.image);
      setLocation(event.location);
      setStartTime(event.startTime);
      setEndTime(event.endTime);
      setCategoryIds(event.categoryIds);
    };

    const fetchCategories = async () => {
      const categoriesResponse = await axios.get(
        "http://localhost:3000/categories"
      );
      setCategories(categoriesResponse.data);
    };

    fetchEvent();
    fetchCategories();
  }, [id]);

  const handleCategoryChange = (categoryId) => {
    setCategoryIds((prevCategoryIds) =>
      prevCategoryIds.includes(categoryId)
        ? prevCategoryIds.filter((id) => id !== categoryId)
        : [...prevCategoryIds, categoryId]
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const updatedEvent = {
      title,
      description,
      image,
      location,
      startTime,
      endTime,
      categoryIds,
    };
    try {
      await axios.put(`http://localhost:3000/events/${id}`, updatedEvent);
      toast({
        title: "Event updated.",
        description: "The event has been updated successfully.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });
      navigate(`/events/${id}`);
    } catch (error) {
      toast({
        title: "An error occurred.",
        description: "Unable to update event.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  return (
    <Box
      as="form"
      onSubmit={handleSubmit}
      bg="lightblue"
      p={5}
      minHeight="100vh"
    >
      <Box mb={4}>
        <Text fontWeight="bold" mb={2}>
          Selected Categories:
        </Text>
        <Box mb={2}>
          {categoryIds.map((id) => (
            <Text key={id}>
              {categories.find((category) => category.id === id)?.name}
            </Text>
          ))}
        </Box>
        <Box>
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => handleCategoryChange(category.id)}
              backgroundColor={
                categoryIds.includes(category.id) ? "green.100" : ""
              }
              mb={2}
              mr={2}
              width="200px"
            >
              {category.name}
            </Button>
          ))}
        </Box>
      </Box>
      <Flex direction={{ base: "column", md: "row" }} wrap="wrap" mb={4}>
        <Box flex="1" p={2}>
          <Input
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            mb={4}
          />
          <Textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            mb={4}
          />
          <Input
            placeholder="Image URL"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            mb={4}
          />
        </Box>
        <Box flex="1" p={2}>
          <Input
            placeholder="Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            mb={4}
          />
          <Input
            type="datetime-local"
            placeholder="Start Time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            mb={4}
          />
          <Input
            type="datetime-local"
            placeholder="End Time"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            mb={4}
          />
        </Box>
      </Flex>
      <Button type="submit">Update Event</Button>
    </Box>
  );
};

export default EditEvent;
