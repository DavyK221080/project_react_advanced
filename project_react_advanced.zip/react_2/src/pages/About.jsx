import React from "react";
import { Box, Heading, Text } from "@chakra-ui/react";

const About = () => {
  return (
    <Box bg="lightblue" p={5} minHeight="100vh">
      <Heading as="h1" size="xl" mb={4}>
        About Page
      </Heading>
      <Text fontSize="lg">
        We are the organizers of this events page. For suggestions or ideas,
        please email: hakkie221080@gmail.com.
      </Text>
    </Box>
  );
};

export default About;
