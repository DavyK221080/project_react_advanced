import React, { useState, useEffect } from "react";
import {
  Box,
  Input,
  Button,
  Textarea,
  Select,
  useToast,
  Flex,
  Image,
  Text,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AddEvent = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [location, setLocation] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [categoryIds, setCategoryIds] = useState([]);
  const [categories, setCategories] = useState([]);
  const [users, setUsers] = useState([]);
  const [createdBy, setCreatedBy] = useState("");
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const result = await axios.get("http://localhost:3000/categories");
        setCategories(result.data);
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };

    const fetchUsers = async () => {
      try {
        const result = await axios.get("http://localhost:3000/users");
        setUsers(result.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchCategories();
    fetchUsers();
  }, []);

  const handleCategoryChange = (categoryId) => {
    setCategoryIds((prevCategoryIds) =>
      prevCategoryIds.includes(categoryId)
        ? prevCategoryIds.filter((id) => id !== categoryId)
        : [...prevCategoryIds, categoryId]
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const newEvent = {
      title,
      description,
      image,
      location,
      startTime,
      endTime,
      categoryIds,
      createdBy,
    };

    try {
      await axios.post("http://localhost:3000/events", newEvent);
      toast({
        title: "Event added.",
        description: "The event has been added successfully.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });
      navigate("/events");
    } catch (error) {
      console.error("Error adding event:", error);
      toast({
        title: "An error occurred.",
        description: "Unable to add event.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  return (
    <Box
      as="form"
      onSubmit={handleSubmit}
      bg="lightblue"
      p={5}
      minHeight="100vh"
    >
      <Flex direction={{ base: "column", md: "row" }} wrap="wrap" mb={4}>
        <Box flex="1" p={2}>
          <Input
            id="title"
            name="title"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            mb={4}
          />
          <Textarea
            id="description"
            name="description"
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            mb={4}
          />
          <Input
            id="image"
            name="image"
            placeholder="Image URL"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            mb={4}
          />
        </Box>
        <Box flex="1" p={2}>
          <Input
            id="location"
            name="location"
            placeholder="Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            mb={4}
          />
          <Input
            id="startTime"
            name="startTime"
            type="datetime-local"
            placeholder="Start Time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            mb={4}
          />
          <Input
            id="endTime"
            name="endTime"
            type="datetime-local"
            placeholder="End Time"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            mb={4}
          />
        </Box>
      </Flex>
      <Box mb={4}>
        <Text fontWeight="bold" mb={2}>
          Selected Categories:
        </Text>
        <Box mb={2}>
          {categoryIds.map((id) => (
            <Text key={id}>
              {categories.find((category) => category.id === id)?.name}
            </Text>
          ))}
        </Box>
        <Box>
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => handleCategoryChange(category.id)}
              backgroundColor={
                categoryIds.includes(category.id) ? "green.100" : ""
              }
              mb={2}
              mr={2}
            >
              {category.name}
            </Button>
          ))}
        </Box>
      </Box>
      <Box mb={4}>
        <Text fontWeight="bold" mb={2}>
          Select Created By:
        </Text>
        <Select
          id="createdBy"
          name="createdBy"
          onChange={(e) => setCreatedBy(e.target.value)}
          width="200px"
        >
          {users.map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </Select>
        {createdBy && (
          <Flex mt={2} align="center">
            <Image
              src={users.find((user) => user.id === Number(createdBy))?.image}
              alt={users.find((user) => user.id === Number(createdBy))?.name}
              boxSize="50px"
              borderRadius="full"
              mr={2}
            />
            <Text>
              {users.find((user) => user.id === Number(createdBy))?.name}
            </Text>
          </Flex>
        )}
      </Box>
      <Button type="submit">Add Event</Button>
    </Box>
  );
};

export default AddEvent;
