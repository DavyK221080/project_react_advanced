import React, { useState, useEffect } from "react";
import {
  Box,
  Text,
  Image,
  Heading,
  Button,
  Input,
  Select,
  Grid,
  GridItem,
  Flex,
  Divider,
} from "@chakra-ui/react";
import { Link } from "react-router-dom";
import axios from "axios";

const EventsPage = () => {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [categories, setCategories] = useState([]);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchEvents = async () => {
      const result = await axios.get("http://localhost:3000/events");
      setEvents(result.data);
    };

    const fetchCategories = async () => {
      const result = await axios.get("http://localhost:3000/categories");
      setCategories(result.data);
    };

    const fetchUsers = async () => {
      const result = await axios.get("http://localhost:3000/users");
      setUsers(result.data);
    };

    fetchEvents();
    fetchCategories();
    fetchUsers();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleFilterChange = (event) => {
    setCategoryFilter(event.target.value);
  };

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (categoryFilter
        ? event.categoryIds.includes(Number(categoryFilter))
        : true)
  );

  const getUserById = (id) => {
    return users.find((user) => user.id === String(id) || user.id === id);
  };

  return (
    <Box bg="lightblue" p={5} minHeight="100vh">
      <Heading color="darkblue">Events</Heading>
      <Input
        id="search-events"
        name="search-events"
        placeholder="Search events"
        value={searchTerm}
        onChange={handleSearch}
        mb={4}
      />
      <Select
        id="filter-category"
        name="filter-category"
        placeholder="Filter by category"
        onChange={handleFilterChange}
        mb={4}
      >
        {categories.map((category) => (
          <option key={category.id} value={category.id}>
            {category.name}
          </option>
        ))}
      </Select>
      <Button as={Link} to="/add-event" mb={4} color="darkblue">
        Add Event
      </Button>
      <Grid templateColumns="repeat(auto-fill, minmax(300px, 1fr))" gap={6}>
        {filteredEvents.map((event) => {
          const creator = getUserById(event.createdBy);
          return (
            <GridItem
              key={event.id}
              as={Link}
              to={`/events/${event.id}`}
              p={5}
              shadow="md"
              borderWidth="1px"
              borderRadius="md"
              bg="white"
            >
              <Image
                src={event.image}
                alt={event.title}
                boxSize="150px"
                objectFit="cover"
                mb={4}
              />
              <Heading fontSize="xl">{event.title}</Heading>
              <Divider my={2} />
              <Box>
                <Text fontWeight="bold">Description:</Text>
                <Text mb={2}>{event.description}</Text>
                <Text fontWeight="bold">Category:</Text>
                <Text mb={2}>
                  {event.categoryIds
                    .map(
                      (id) =>
                        categories.find(
                          (category) => category.id === String(id)
                        )?.name
                    )
                    .filter(Boolean)
                    .join(", ")}
                </Text>
                <Text fontWeight="bold">Location:</Text>
                <Text mb={2}>{event.location}</Text>
                <Text fontWeight="bold">Start Time:</Text>
                <Text mb={2}>{new Date(event.startTime).toLocaleString()}</Text>
                <Text fontWeight="bold">End Time:</Text>
                <Text mb={2}>{new Date(event.endTime).toLocaleString()}</Text>
              </Box>
              {creator && (
                <Flex mt={4} align="center">
                  <Image
                    src={creator.image}
                    alt={creator.name}
                    boxSize="30px"
                    borderRadius="full"
                    mr={2}
                  />
                  <Text>{creator.name}</Text>
                </Flex>
              )}
            </GridItem>
          );
        })}
      </Grid>
    </Box>
  );
};

export default EventsPage;
