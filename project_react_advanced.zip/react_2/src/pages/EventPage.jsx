import React, { useState, useEffect } from "react";
import {
  Box,
  Image,
  Heading,
  Text,
  Button,
  Input,
  Textarea,
  Select,
  useToast,
  Flex,
  Divider,
} from "@chakra-ui/react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EventPage = () => {
  const { id: eventId } = useParams();
  const [event, setEvent] = useState(null);
  const [creator, setCreator] = useState(null);
  const [categories, setCategories] = useState([]);
  const [users, setUsers] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [location, setLocation] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [categoryIds, setCategoryIds] = useState([]);
  const [createdBy, setCreatedBy] = useState("");
  const toast = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const eventResponse = await axios.get(
          `http://localhost:3000/events/${eventId}`
        );
        const eventData = eventResponse.data;
        setEvent(eventData);
        setTitle(eventData.title);
        setDescription(eventData.description);
        setImage(eventData.image);
        setLocation(eventData.location);
        setStartTime(eventData.startTime);
        setEndTime(eventData.endTime);
        setCategoryIds(eventData.categoryIds.map(String));
        setCreatedBy(String(eventData.createdBy));

        if (eventData.createdBy) {
          const creatorResponse = await axios.get(
            `http://localhost:3000/users/${eventData.createdBy}`
          );
          setCreator(creatorResponse.data);
        }
      } catch (error) {
        console.error("Error fetching event or user data:", error);
      }
    };

    const fetchCategories = async () => {
      try {
        const categoriesResponse = await axios.get(
          "http://localhost:3000/categories"
        );
        setCategories(categoriesResponse.data);
      } catch (error) {
        console.error("Error fetching categories data:", error);
      }
    };

    const fetchUsers = async () => {
      try {
        const usersResponse = await axios.get("http://localhost:3000/users");
        setUsers(usersResponse.data);
      } catch (error) {
        console.error("Error fetching users data:", error);
      }
    };

    fetchEvent();
    fetchCategories();
    fetchUsers();
  }, [eventId]);

  const handleCategoryChange = (categoryId) => {
    setCategoryIds((prevCategoryIds) =>
      prevCategoryIds.includes(categoryId)
        ? prevCategoryIds.filter((id) => id !== categoryId)
        : [...prevCategoryIds, categoryId]
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const updatedEvent = {
      title,
      description,
      image,
      location,
      startTime,
      endTime,
      categoryIds,
      createdBy,
    };
    try {
      await axios.put(`http://localhost:3000/events/${eventId}`, updatedEvent);
      toast({
        title: "Event updated.",
        description: "The event has been updated successfully.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });
      setEvent(updatedEvent);
      setIsEditing(false);
    } catch (error) {
      toast({
        title: "An error occurred.",
        description: "Unable to update event.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  const handleDelete = async () => {
    if (window.confirm("Are you sure you want to delete this event?")) {
      try {
        await axios.delete(`http://localhost:3000/events/${eventId}`);
        toast({
          title: "Event deleted.",
          description: "The event has been deleted successfully.",
          status: "success",
          duration: 5000,
          isClosable: true,
        });
        navigate("/events");
      } catch (error) {
        toast({
          title: "An error occurred.",
          description: "Unable to delete event.",
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      }
    }
  };

  if (!event) return <div>Loading...</div>;

  return (
    <Box p={5} bg="lightblue" minHeight="100vh">
      {isEditing ? (
        <Box as="form" onSubmit={handleSubmit}>
          <Box mb={4}>
            <Text fontWeight="bold" mb={2}>
              Selected Categories:
            </Text>
            <Box mb={2}>
              {categoryIds.map((id) => (
                <Text key={id}>
                  {categories.find((category) => category.id === id)?.name}
                </Text>
              ))}
            </Box>
            <Box>
              {categories.map((category) => (
                <Button
                  key={category.id}
                  onClick={() => handleCategoryChange(category.id)}
                  backgroundColor={
                    categoryIds.includes(category.id) ? "green.100" : ""
                  }
                  mb={2}
                  mr={2}
                  width="200px"
                >
                  {category.name}
                </Button>
              ))}
            </Box>
          </Box>
          <Box mb={4}>
            <Text fontWeight="bold" mb={2}>
              Select Created By:
            </Text>
            <Select
              id="createdBy"
              name="createdBy"
              onChange={(e) => setCreatedBy(e.target.value)}
              value={createdBy}
              width="200px" // Set fixed width
            >
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </Select>
            {createdBy && (
              <Flex mt={2} align="center">
                <Image
                  src={
                    users.find((user) => user.id === Number(createdBy))?.image
                  }
                  alt={
                    users.find((user) => user.id === Number(createdBy))?.name
                  }
                  boxSize="50px"
                  borderRadius="full"
                  mr={2}
                />
                <Text>
                  {users.find((user) => user.id === Number(createdBy))?.name}
                </Text>
              </Flex>
            )}
          </Box>
          <Flex direction={{ base: "column", md: "row" }} wrap="wrap" mb={4}>
            <Box flex="1" p={2}>
              <Input
                id="title"
                name="title"
                placeholder="Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                mb={4}
              />
              <Textarea
                id="description"
                name="description"
                placeholder="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                mb={4}
              />
              <Input
                id="image"
                name="image"
                placeholder="Image URL"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                mb={4}
              />
            </Box>
            <Box flex="1" p={2}>
              <Input
                id="location"
                name="location"
                placeholder="Location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                mb={4}
              />
              <Input
                id="startTime"
                name="startTime"
                type="datetime-local"
                placeholder="Start Time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                mb={4}
              />
              <Input
                id="endTime"
                name="endTime"
                type="datetime-local"
                placeholder="End Time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                mb={4}
              />
            </Box>
          </Flex>
          <Button type="submit">Update Event</Button>
          <Button onClick={() => setIsEditing(false)} ml={4}>
            Cancel
          </Button>
        </Box>
      ) : (
        <>
          <Flex direction={{ base: "column", md: "row" }} mb={4}>
            <Image
              src={event.image}
              alt={event.title}
              boxSize="200px"
              objectFit="cover"
              mb={4}
            />
            <Box ml={{ base: 0, md: 4 }} flex="1">
              <Heading>{event.title}</Heading>
              <Divider my={2} />
              <Box>
                <Text fontWeight="bold">Description:</Text>
                <Text mb={2}>{event.description}</Text>
                <Text fontWeight="bold">Location:</Text>
                <Text mb={2}>{event.location}</Text>
                <Text fontWeight="bold">Start Time:</Text>
                <Text mb={2}>{new Date(event.startTime).toLocaleString()}</Text>
                <Text fontWeight="bold">End Time:</Text>
                <Text mb={2}>{new Date(event.endTime).toLocaleString()}</Text>
                <Text fontWeight="bold">Categories:</Text>
                <Text mb={2}>
                  {event.categoryIds
                    .map(
                      (id) =>
                        categories.find(
                          (category) => category.id === String(id)
                        )?.name
                    )
                    .join(", ")}
                </Text>
              </Box>
              {creator && (
                <Flex mt={4} align="center">
                  <Image
                    src={creator.image}
                    alt={creator.name}
                    boxSize="30px"
                    borderRadius="full"
                    mr={2}
                  />
                  <Text>{creator.name}</Text>
                </Flex>
              )}
            </Box>
          </Flex>
          <Button colorScheme="blue" onClick={() => setIsEditing(true)} mt={4}>
            Edit
          </Button>
          <Button colorScheme="red" onClick={handleDelete} mt={4} ml={4}>
            Delete
          </Button>
        </>
      )}
    </Box>
  );
};

export default EventPage;
