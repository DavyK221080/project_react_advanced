import React from "react";
import { Box, Heading, Text } from "@chakra-ui/react";

const Home = () => {
  return (
    <Box bg="lightblue" p={5} minHeight="100vh">
      <Heading as="h1" size="xl" mb={4}>
        Home Page
      </Heading>
      <Text fontSize="lg">Welcome to our Events Page.</Text>
    </Box>
  );
};

export default Home;
